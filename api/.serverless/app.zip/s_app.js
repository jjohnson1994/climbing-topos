
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jjohnson1994',
  applicationName: 'climbing-topos',
  appUid: 'wGlSNfqGyvSPDGtxhh',
  orgUid: 'Wn7fgrmVBhw49ljZZB',
  deploymentUid: '80c6252d-3caa-42d2-a019-1156026570f7',
  serviceName: 'climbing-topos',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'climbing-topos-dev-app', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}